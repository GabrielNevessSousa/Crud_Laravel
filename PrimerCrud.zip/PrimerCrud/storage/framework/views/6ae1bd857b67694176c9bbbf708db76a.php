



<?php $__env->startSection('contenido'); ?>

<a href="<?php echo e(url('pokemons/create')); ?>" class="btn btn-primary btn-sm">Nuevo Pokemon</a>


<table class="table table-hover">

    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Tipo</th>
            <th>Tamaño</th>
            <th>Peso</th>
            <th>Acciones</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($pokemon->id); ?></td>
            <td><?php echo e($pokemon->Nombre); ?></td>
            <td><?php echo e($pokemon->Tipo); ?></td>
            <td><?php echo e($pokemon->Tamaño); ?></td>
            <td><?php echo e($pokemon->Peso); ?></td>
     <td>      <a href="<?php echo e(url('pokemons/' . $pokemon->id . '/edit')); ?>" class="btn btn-primary btn-sm">Editar Pokemon</a>

            <td>
                <form action="<?php echo e(url('pokemons/'.$pokemon->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Eliminar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PrimerCrud\resources\views/pokemons/index.blade.php ENDPATH**/ ?>