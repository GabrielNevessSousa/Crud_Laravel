<?php

namespace App\Http\Controllers;

use App\Models\PokemonModel;
use Illuminate\Http\Request;

class pokemonController extends Controller
{
    public function index()
{
    $pokemons = PokemonModel::all();
    return view('pokemons.index', ['pokemons' => $pokemons]);
}

    
    public function create()
    {
        // Muestra el formulario para crear una nueva tarea
        return view('pokemons.create');
    }
    
    public function store(Request $request)
    {
        // Validación de datos
        $request->validate([
            'nombre' => 'required|max:255',
            'tipo' => 'nullable',
            'tamaño' => 'required|max:255',
            'peso' => 'required',
        ]);
    
        // Crear una nueva instancia de PokemonModel con los datos del formulario
        $pokemon = new PokemonModel([
            'nombre' => $request->input('nombre'),
            'tipo' => $request->input('tipo'),
            'tamaño' => $request->input('tamaño'),
            'peso' => $request->input('peso'),
        ]);
    
        // Guardar el PokemonModel en la base de datos
        $pokemon->save();
    
        // Redirigir a la lista de pokemons con un mensaje
        return redirect()->route('pokemons.index')->with('success', 'Pokemon creado correctamente');
    }
    
    
    public function show($id)
    {
        // Muestra los detalles de una tarea específica
    }
    
  public function edit($id)
{
    $pokemon = PokemonModel::find($id);

    return view('pokemons.edit', ['pokemon' => $pokemon]);
    // Muestra el formulario para editar una tarea específica
}

    
    public function update(Request $request, $id)
    {
        // Validate the request data
        $request->validate([
            'nombre' => 'required|max:255',
            'tipo' => 'nullable',
            'tamaño' => 'required|max:255',
            'peso' => 'required',
        ]);
    
        // Find the Pokemon by ID
        $pokemon = PokemonModel::find($id);
    
        // Update the Pokemon data
        $pokemon->update([
            'nombre' => $request->input('nombre'),
            'tipo' => $request->input('tipo'),
            'tamaño' => $request->input('tamaño'),
            'peso' => $request->input('peso'),
        ]);
    
        // Redirect to the index page or show success message
        return redirect()->route('pokemons.index')->with('success', 'Pokemon actualizado correctamente');
    }
    
    
    public function destroy($id)
    {
        // Elimina una tarea de la base de datos

        $pokemons = PokemonModel::find($id);
        $pokemons->delete();

        return redirect("pokemons");
    }
    
}